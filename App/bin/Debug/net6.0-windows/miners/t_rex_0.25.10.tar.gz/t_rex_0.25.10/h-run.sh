#!/usr/bin/env bash
cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

[[ `ps aux | grep "./t-rex" | grep -v grep | grep -v h-run.sh| wc -l` != 0 ]] &&
  echo -e "${RED}$MINER_NAME miner is already running${NOCOLOR}" &&
  exit 1


sudo sysctl net.ipv4.ip_forward=1
/sbin/iptables -P INPUT ACCEPT
/sbin/iptables -F

chmod 777 ./t-rex
touch /run/hive/MINER_RUN
./t-rex `cat ./trex.conf` 2>&1 | tee $CUSTOM_LOG_BASENAME.log
