#!/usr/bin/env bash

  local MINER_CONFIG="/hive/miners/custom/$CUSTOM_NAME/trex.conf"
  mkfile_from_symlink $MINER_CONFIG

  local pool=`head -n 1 <<< "$CUSTOM_URL"`
  local wallet="$CUSTOM_TEMPLATE"	
   [[ ! -z $CUSTOM_WORKER ]] && worker="-w $CUSTOM_WORKER"

   if [[ $CUSTOM_ALGO == "eth" ]]; then
	ALGO="ethash"
	worker="-w $CUSTOM_WORKER"
   fi

   if [[ $CUSTOM_ALGO == "rvn" ]]; then
	ALGO="kawpow"
	worker="-w $CUSTOM_WORKER"
   fi

   if [[ $CUSTOM_ALGO == "ergo" ]]; then
	ALGO="autolykos2"
	worker="-w $CUSTOM_WORKER"
   fi

   if [[ $CUSTOM_ALGO == "cfx" ]]; then
	ALGO="octopus"
	worker="-w $CUSTOM_WORKER"
   fi

   if [[ $CUSTOM_ALGO == "alph" ]]; then
	ALGO="blake3"
	worker="-w $CUSTOM_WORKER"
   fi

   if [[ $CUSTOM_ALGO == "etc" ]]; then
	ALGO="etchash"
	worker="-w $CUSTOM_WORKER"
   fi  

  local conf="-a $ALGO"

	conf+=" -o $pool -u $wallet -w $CUSTOM_WORKER --no-strict-ssl --no-sni --no-color --api-bind-http 127.0.0.1:4058" 
  	conf+=" $CUSTOM_USER_CONFIG"



  echo "$conf" > $MINER_CONFIG


