#!/usr/bin/env bash


  local MINER_CONFIG="/hive/miners/custom/$CUSTOM_NAME/nbminer.conf"
  mkfile_from_symlink $MINER_CONFIG

  local pool=`head -n 1 <<< "$CUSTOM_URL"`
  local wallet="$CUSTOM_TEMPLATE"	


   [[ ! -z $CUSTOM_WORKER ]] && worker=".$CUSTOM_WORKER"


   if [[ $CUSTOM_ALGO == "eth" ]]; then
	ALGO="ethash"
	worker=".$CUSTOM_WORKER"	
   fi
   if [[ $CUSTOM_ALGO == "etc" ]]; then
	ALGO="etchash"
	worker=".$CUSTOM_WORKER"	
   fi

   if [[ $CUSTOM_ALGO == "ae" ]]; then
	ALGO="cuckoo_ae"
	worker=".$CUSTOM_WORKER"
   fi

   if [[ $CUSTOM_ALGO == "rvn" ]]; then
	ALGO="kawpow"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "conflux" ]]; then
	ALGO="octopus"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "ergo" ]]; then
	ALGO="ergo"
	worker=".$CUSTOM_WORKER"
   fi


  local conf="-a $ALGO"

	conf+=" -o $pool -u $wallet$worker -api 0.0.0.0:$MINER_API_PORT" 
  	conf+=" $dw"
  	conf+=" $CUSTOM_USER_CONFIG"



  echo "$conf" > $MINER_CONFIG

