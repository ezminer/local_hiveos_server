#!/usr/bin/env bash

  local MINER_CONFIG="/hive/miners/custom/$CUSTOM_NAME/gminer.conf"
  mkfile_from_symlink $MINER_CONFIG
#flux
#miner --user t1dSUywPvxkCWGPv1ynA76vWwum42CaZ4mL.8888 --server us-flux.fluxpools.net --port 2001 --pass 9999 --algo 125_4 --pers ZelProof
#lolMiner --user t1dSUywPvxkCWGPv1ynA76vWwum42CaZ4mL.8888 --port 2001 --pool us-flux.fluxpools.net --pass 9999 --coin flux

   if [[ $CUSTOM_ALGO == "grin29" ]]; then
	ALGO="grin29"
	worker="/$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "beam" ]]; then
#	ALGO="150_5" BeamHash
	ALGO="beamhash --opencl 0 --ssl 1"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "grin31" ]]; then
	ALGO="grin31"
	worker="/$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "ae" ]]; then
	ALGO="aeternity"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "vds" ]]; then
	ALGO="vds"
	worker=".$CUSTOM_WORKER"
	  if [[ ${CUSTOM_URL} =~ "666pool" ]]; then 
 	  worker="@pplns.$CUSTOM_WORKER"
 	  fi
   fi
   if [[ $CUSTOM_ALGO == "yec" ]]; then
	ALGO="192_7 --pers ZcashPoW"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "grimm" ]]; then
	ALGO="150_5 --pers GrimmPOW"
	worker=".$CUSTOM_WORKER --ssl 1"
   fi
   if [[ $CUSTOM_ALGO == "etc" ]]; then
	ALGO="etc"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "flux" ]]; then
	ALGO="125_4 --pers ZelProof --pec"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "eth" ]]; then
	ALGO="ethash"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "ctxc" ]]; then
	ALGO="cortex"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "kda" ]]; then
	ALGO="blake2s"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "bbc" ]]; then
	ALGO="bbc"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "xmv" ]]; then
	ALGO="cuckarood29v"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "mwc" ]]; then
	ALGO="cuckarood29"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "grin32" ]]; then
	ALGO="grin32"
	worker="/$CUSTOM_WORKER"
	  if [[ ${CUSTOM_URL} =~ "2miners" ]]; then 
 	  worker=".$CUSTOM_WORKER"
 	  fi
   fi
   if [[ $CUSTOM_ALGO == "hns" ]]; then
	ALGO="handshake"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "aion" ]]; then
	ALGO="210_9 --pers AION0PoW"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "pmeer" ]]; then
	ALGO="cuckoo24"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "rvn" ]]; then
	ALGO="kawpow"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "yec" ]]; then
	ALGO=" 192_7 --pers ZcashPoW"
	worker=".$CUSTOM_WORKER"
   fi
   if [[ $CUSTOM_ALGO == "flux" ]]; then
	ALGO=" 125_4"
	worker=".$CUSTOM_WORKER"
   fi

  local conf="--algo $ALGO"

  local host=${CUSTOM_URL%:*}
if [[ ${host} =~ ":" ]]; then 
host=${host#*//}
fi

  local port=${CUSTOM_URL#*:}
if [[ ${port} =~ ":" ]]; then 
port=${port#*:}
fi

#  [[ ! -z $CUSTOM_WORKER ]] && worker=".$CUSTOM_WORKER"

#  for (( i = 1; i <= `wc -w <<< $CUSTOM_HOST`; i++ )); do
#    host=`awk '(NR == '$i')' <<< "$CUSTOM_HOST"`
#    [[ ! -z `awk '(NR == '$i')' <<< "$CUSTOM_PORT"` ]] && port=`awk '(NR == '$i')' <<< "$CUSTOM_PORT"`#

   conf+=" --server $host --port $port --user $CUSTOM_TEMPLATE$worker  --pass x --color 0"
#    [[ ! -z $CUSTOM_PASS ]] && conf+=" --pass $CUSTOM_PASS"
#  done

#  local pool=`head -n 1 <<< "$CUSTOM_URL"`



#  [[ $CUSTOM_TLS -eq 1 ]] && conf+=" --ssl 1"
if [[ ${CUSTOM_URL} =~ "stratum+ssl" ]]; then 
	conf+=" --ssl 1"
fi

  conf+=" $CUSTOM_USER_CONFIG"

  echo "$conf" > $MINER_CONFIG

